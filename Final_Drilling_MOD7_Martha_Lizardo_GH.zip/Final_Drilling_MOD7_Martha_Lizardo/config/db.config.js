import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('db_bootcamp', 'postgres', 'Hola123+', {
    host: 'localhost',
    dialect: 'postgres', 
    logging: false, // O true si quieres ver las consultas en la consola
});

export default sequelize;
