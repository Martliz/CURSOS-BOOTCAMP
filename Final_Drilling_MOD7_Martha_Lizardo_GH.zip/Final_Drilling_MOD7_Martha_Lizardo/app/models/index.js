import Sequelize from 'sequelize';
import sequelize from '../db.config.js'; // Ajusta la ruta si es necesario

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// Aquí puedes importar y añadir modelos, por ejemplo:
import User from '../../models/user.model.js';
import Bootcamp from '../../models/bootcamp.model.js';

db.User = User(sequelize, Sequelize);
db.Bootcamp = Bootcamp(sequelize, Sequelize);

export default db;
