import sequelize from '../config/db.config.js';
import UserModel from './user.model.js';
import BootcampModel from './bootcamp.model.js';

// Inicializar modelos
const User = UserModel(sequelize, sequelize.Sequelize.DataTypes);
const Bootcamp = BootcampModel(sequelize, sequelize.Sequelize.DataTypes);

// Establecer relaciones
Bootcamp.belongsToMany(User, {
    through: 'user_bootcamp',
    as: 'Users',
    foreignKey: 'BootcampId',
    otherKey: 'UserId',
});

User.belongsToMany(Bootcamp, {
    through: 'user_bootcamp',
    as: 'Bootcamps',
    foreignKey: 'UserId',
    otherKey: 'BootcampId',
});

// Exportar modelos y conexión
export { sequelize, User, Bootcamp };

