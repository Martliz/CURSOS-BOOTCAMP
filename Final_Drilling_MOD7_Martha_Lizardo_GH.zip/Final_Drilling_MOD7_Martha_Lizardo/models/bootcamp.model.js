import { DataTypes } from 'sequelize';

export default (sequelize) => {
    return sequelize.define('Bootcamp', {
        title: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        cue: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                min: 5,
                max: 10,
            },
        },
        description: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    }, {
        tableName: 'bootcamps', // Nombre explícito en minúsculas
    });
};
