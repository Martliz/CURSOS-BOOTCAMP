import { Bootcamp, User } from '../models/index.js';

// Crear Bootcamp
export const createBootcamp = async (req, res) => {
    try {
        const { title, cue, description } = req.body;
        if (cue < 5 || cue > 10) return res.status(400).json({ error: 'El CUE debe estar entre 5 y 10' });
        const bootcamp = await Bootcamp.create({ title, cue, description });
        res.status(201).json(bootcamp);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Agregar usuario al Bootcamp
export const addUser = async (req, res) => {
    try {
        const { bootcampId, userId } = req.params;
        if (isNaN(bootcampId) || isNaN(userId)) return res.status(400).json({ error: 'IDs inválidos' });
        const bootcamp = await Bootcamp.findByPk(bootcampId);
        const user = await User.findByPk(userId);
        if (!bootcamp || !user) return res.status(404).json({ error: 'Bootcamp o Usuario no encontrado' });
        await bootcamp.addUser(user);
        res.status(200).json({ message: 'Usuario agregado al Bootcamp exitosamente' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Obtener Bootcamp por ID
export const findById = async (req, res) => {
    try {
        const bootcamp = await Bootcamp.findByPk(req.params.id, { include: { model: User, as: 'Users' } });
        if (!bootcamp) return res.status(404).json({ error: 'Bootcamp no encontrado' });
        res.status(200).json(bootcamp);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Obtener todos los Bootcamps
export const findAll = async (req, res) => {
    try {
        const bootcamps = await Bootcamp.findAll({ include: { model: User, as: 'Users' } });
        res.status(200).json(bootcamps);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
