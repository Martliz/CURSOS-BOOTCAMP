import express from 'express';
import { sequelize, User, Bootcamp } from './models/index.js';
import { createUser, findAll, findUserById, updateUserById, deleteUserById } from './controllers/user.controller.js';
import { createBootcamp, addUser, findById, findAll as findAllBootcamps } from './controllers/bootcamp.controller.js';

const app = express();
const PORT = 3000;

app.use(express.json());

// Rutas de usuarios
app.post('/users', createUser); 
app.get('/users', findAll);
app.get('/users/:id', findUserById);
app.put('/users/:id', updateUserById);
app.delete('/users/:id', deleteUserById);

// Rutas de Bootcamp
app.post('/bootcamps', createBootcamp);
app.post('/bootcamps/:bootcampId/users/:userId', addUser);
app.get('/bootcamps', async (req, res) => {
    try {
        const bootcamps = await Bootcamp.findAll({ include: { model: User, as: 'Users' } });
        res.json(bootcamps);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.get('/bootcamps/:id', async (req, res) => {
    try {
        const bootcamp = await Bootcamp.findByPk(req.params.id, { include: { model: User, as: 'Users' } });
        if (!bootcamp) return res.status(404).json({ error: 'Bootcamp no encontrado' });
        res.json(bootcamp);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Ruta raíz
app.get('/', (req, res) => {
    res.status(200).send({ message: 'Bienvenido a la API de Bootcamps' });
});

// Sincronización de modelos y datos iniciales
sequelize.sync({ force: true }).then(async () => {
    console.log('Base de datos sincronizada');
    
    // Crear usuarios iniciales
    const users = [
        { firstName: 'Mateo', lastName: 'Díaz', email: 'mateo.diaz@correo.com' },
        { firstName: 'Santiago', lastName: 'Mejías', email: 'santiago.mejias@correo.com' },
        { firstName: 'Lucas', lastName: 'Rojas', email: 'lucas.rojas@correo.com' },
        { firstName: 'Facundo', lastName: 'Fernandez', email: 'facundo.fernandez@correo.com' },
    ];
    for (const userData of users) {
        try {
            await User.create(userData);
        } catch (error) {
            console.error(`Error al crear usuario ${userData.firstName}:`, error.message);
        }
    }

    // Crear Bootcamp inicial
    try {
        await Bootcamp.create({
            title: 'Bootcamp Node.js',
            cue: 7,
            description: 'Un Bootcamp intensivo para aprender Node.js desde cero.',
        });
    } catch (error) {
        console.error('Error al crear Bootcamp:', error.message);
    }

    app.listen(PORT, () => {
        console.log(`Servidor corriendo en el puerto ${PORT}`);
    });
}).catch((err) => {
    console.error('Error al sincronizar la base de datos:', err);
});
